import "./App.css"
import VideoEditor from "./components/VideoEditor"

function App() {
    return (
        <div className={"app"}>
            <VideoEditor />
        </div>
    )
}

export default App